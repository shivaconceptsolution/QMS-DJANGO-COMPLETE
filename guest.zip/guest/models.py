from django.db import models

class Fupload(models.Model):
	filepath = models.CharField(max_length=100)
