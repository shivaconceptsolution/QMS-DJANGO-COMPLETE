from django.urls import path
from . import views

urlpatterns=[
path('',views.index,name='index'),
path('scookie',views.scookie,name='scookie'),
path('gcookie',views.gcookie,name='gcookie'),
path('fupload',views.fupload,name='fupload'),
path('vupload',views.vupload,name='vupload'),
path('deletefile',views.deletefile,name='deletefile'),
path('ajaxload',views.ajaxload,name='ajaxload'),
path('ajaxdata',views.ajaxdata,name='ajaxdata'),
]