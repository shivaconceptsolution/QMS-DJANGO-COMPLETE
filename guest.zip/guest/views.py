from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
def index(request):
  return render(request,"guest/index.html")

def gcookie(request):
  a = request.COOKIES["ckey"]
  return HttpResponse(a)


def scookie(request):
   response = HttpResponse("cooki set example")
   response.set_cookie('ckey',"Welcome in SCS Concept")
   return response
  
def fupload(request):
  if request.method == 'POST' and request.FILES['myfile']:
    myfile = request.FILES['myfile']
    fs = FileSystemStorage()
    filename = fs.save(myfile.name, myfile)
    res = fs.url(filename)
    return render(request, 'guest/fupload.html',{'key':res})
  return render(request, 'guest/fupload.html')  

