from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from . models import Fupload
from hrapp.models import Reg
def index(request):
  return render(request,"guest/index.html")

def gcookie(request):
  a = request.COOKIES["ckey"]
  return HttpResponse(a)


def scookie(request):
   response = HttpResponse("cooki set example")
   response.set_cookie('ckey',"Welcome in SCS Concept")
   return response
  
def fupload(request):
  if request.method == 'POST' and request.FILES['myfile']:
    myfile = request.FILES['myfile']
    fs = FileSystemStorage()
    filename = fs.save(myfile.name, myfile)
    res = fs.url(filename)
    obj = Fupload(filepath=res)
    obj.save()
    return render(request, 'guest/fupload.html',{'key':res})
  return render(request, 'guest/fupload.html')  

def vupload(request):
   return render(request, 'guest/vupload.html',{'res':Fupload.objects.all()})  

def deletefile(request):
    s = Fupload.objects.get(pk=request.GET["q"])
    s.delete()
    return redirect('vupload')   

def ajaxload(request):
    return render(request,"guest/ajaxsearch.html")

def ajaxdata(request):
    data = request.GET["q"]
    if data != "":
     result = Reg.objects.filter(fname__contains=data)
     return render(request,"guest/ajaxdata.html",{'res':result})
    else:
      return HttpResponse("Data Invalid")  