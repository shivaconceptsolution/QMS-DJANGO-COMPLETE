from django.shortcuts import render,redirect
from hrapp.models import Reg,Feedback,Replyto
def index(request):
    return render(request,"customerapp/index.html")

def loginlogic(request):
     obj = Reg.objects.filter(username=request.POST["txtu"],password=request.POST['txtp'],role='customer')
     if obj.count()>0:
        request.session['cid']=request.POST["txtu"]
        return redirect('/customerapp/dashboard')
     else:
         return HttpResponse("Login not successfully")   

def reglogic(request):
    if request.method=="POST":
        if Reg.objects.filter(username=request.POST["txtuser"]).count()==0:
             obj = Reg(username=request.POST["txtuser"],password=request.POST["txtpass"],role='customer',fname=request.POST["txtfname"], email=request.POST["txtemail"])
             obj.save()
             return render(request,"customerapp/index.html",{"key":'reg successfully'})
        else:
             return render(request,"customerapp/index.html",{"key":'this username already exist'})
    return render(request,"customerapp/index.html")         


def dashboard(request):
    if request.session.has_key("cid"):
     if request.method=="POST":
        obj = Feedback(feedto=request.POST["txtfeedto"],feedby=request.session['cid'],rating=request.POST["txtrating"],fdesc=request.POST["txtdesc"])
        obj.save()
        return render(request,"customerapp/dashboard.html",{"msg":"data submitted successfully"})
     return render(request,"customerapp/dashboard.html",{"res":Replyto.objects.filter(custid=request.session['cid'])})
    else:
       return redirect("/customerapp/") 

def logout(request):
    del request.session['cid'] 
    return redirect("/customerapp/")    
