from django.shortcuts import render
from django.http import HttpResponse
def index(request):
  return render(request,"guest/index.html")

def gcookie(request):
  a = request.COOKIES["ckey"]
  return HttpResponse(a)


def scookie(request):
   response = HttpResponse("cooki set example")
   response.set_cookie('ckey',"Welcome in SCS Concept")
   return response
  

