from django.contrib import admin
from .models import Reg,Feedback,Replyto
admin.site.register(Reg)
admin.site.register(Feedback)
admin.site.register(Replyto)
