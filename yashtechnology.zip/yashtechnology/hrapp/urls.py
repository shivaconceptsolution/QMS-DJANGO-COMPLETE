from django.urls import path

from. import views

urlpatterns = [

    path('', views.index, name='index'),
    path('loginlogic', views.loginlogic, name='loginlogic'),

    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('findrec', views.findrec, name='findrec'),
    path('findrec1', views.findrec1, name='findrec1'),
    path('updaterec', views.updaterec, name='updaterec'),
    path('deleterec', views.deleterec, name='deleterec'),
    path('recruit', views.recruit, name='recruit'),
    path('viewemp', views.viewemp, name='viewemp'),
    path('logout',views.logout,name='logout')


 ]
